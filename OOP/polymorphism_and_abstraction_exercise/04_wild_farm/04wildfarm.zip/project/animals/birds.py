from abc import ABC, abstractmethod

from project.animals.animal import Bird


class Owl(Bird):
  def make_sound(self) -> str:
    return "Hoot Hoot" 
  

class Hen(Bird):
  def make_sound(self) -> str:
    return "Cluck"
    

  