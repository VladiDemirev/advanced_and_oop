from abc import ABC, abstractmethod

from project.animals.animal import Mammal
    
  
class Mouse(Mammal):
  def make_sound(self) -> str:
    return "Squek"


class Dog(Mammal):
  def make_sound(self) -> str:
    return "Cluck"


class Cat(Mammal):
  def make_sound(self) -> str:
    return "Meow"


class Tiger(Mammal):
  def make_sound(self) -> str:
    return "ROAR!!!"
